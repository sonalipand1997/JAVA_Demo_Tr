const Deleteprofile =()=>{
    return (
    <div>
    <h1>You have Deleted Your Profile </h1>
    <h1>You have Deleted Your Profile </h1>
    </div>
    )
}
export default Deleteprofile
