package com.example.entities;

import java.sql.*;
import java.util.Date;

import javax.persistence.*;
import javax.persistence.Table;

@Entity
@Table(name="payment")
public class PaymentDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(length = 20,nullable = false)
	private String transactionId;
	@Column(length = 20,nullable = false)
	private Double paidAmount;
	@Column(nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date paymentDate=new Date();
	@Column(length = 20,nullable = false)
	private PaymentMode paymentMode;
	
	/*
	 * @OneToOne(mappedBy = "payment",cascade = CascadeType.ALL, orphanRemoval =
	 * true)
	 * 
	 * @JsonIgnoreProperties("payment") private Requests request;
	 */
	
	@OneToOne(mappedBy = "payment",cascade = CascadeType.ALL, orphanRemoval = true)
	private Order order;

	
	
	public PaymentDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PaymentDetails(String transactionId, Double paidAmount, Date paymentDate, PaymentMode paymentMode,
			Order order) {
		super();
		this.transactionId = transactionId;
		this.paidAmount = paidAmount;
		this.paymentDate = paymentDate;
		this.paymentMode = paymentMode;
		this.order = order;
	}

	public PaymentDetails(String transactionId, Double paidAmount, PaymentMode paymentMode) {
		super();
		this.transactionId = transactionId;
		this.paidAmount = paidAmount;
//		this.paymentDate = paymentDate;
		this.paymentMode = paymentMode;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public Double getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(Double paidAmount) {
		this.paidAmount = paidAmount;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public PaymentMode getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(PaymentMode paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return "PaymentDetails [id=" + id + ", transactionId=" + transactionId + ", paidAmount=" + paidAmount
				+ ", paymentDate=" + paymentDate + ", paymentMode=" + paymentMode + ", order=" + order + "]";
	}
	
	

}
