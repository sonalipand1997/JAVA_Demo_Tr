package com.example.entities;

public enum OrderStatus {
	
	REQUESTED,ACCEPTED,INPROGRESS,COMPLETED,DECLINED;

}
