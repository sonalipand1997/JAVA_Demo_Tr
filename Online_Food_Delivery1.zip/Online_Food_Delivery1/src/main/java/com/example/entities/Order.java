package com.example.entities;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="order_details")
public class Order {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int order_id;

@OneToOne
@JoinColumn(name="cart_id")
@JsonIgnore
private Cart cart;

@ManyToOne(  /* fetch = FetchType.LAZY */)
@JoinColumn(name = "user_id") // to specify name of the FK column
@JsonIgnore
private User user;

@OneToOne(cascade = CascadeType.ALL)
@JoinColumn(name = "pid")
private PaymentDetails payment;


private OrderStatus status;

public Order() {
	super();
	// TODO Auto-generated constructor stub
}

public Order(Cart cart, User user, PaymentDetails payment, OrderStatus status) {
	super();
	this.cart = cart;
	this.user = user;
	this.payment = payment;
	this.status = status;
}

public int getOrder_id() {
	return order_id;
}

public void setOrder_id(int order_id) {
	this.order_id = order_id;
}

public Cart getCart() {
	return cart;
}

public void setCart(Cart cart) {
	this.cart = cart;
}

public User getUser() {
	return user;
}

public void setUser(User user) {
	this.user = user;
}

public PaymentDetails getPayment() {
	return payment;
}

public void setPayment(PaymentDetails payment) {
	this.payment = payment;
}

public OrderStatus getStatus() {
	return status;
}

public void setStatus(OrderStatus status) {
	this.status = status;
}

@Override
public String toString() {
	return "Order [order_id=" + order_id + ", cart=" + cart + ", user=" + user + ", payment=" + payment + ", status="
			+ status + "]";
}


}
