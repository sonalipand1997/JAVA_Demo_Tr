package com.example.entities;

public enum PaymentMode {
	
	CASH,CHEQUE,BANK_TRANSFER,UPI


}
