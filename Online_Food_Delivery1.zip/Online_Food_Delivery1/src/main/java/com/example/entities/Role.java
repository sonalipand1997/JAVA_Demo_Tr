package com.example.entities;

public enum Role {
	ADMIN,USER,RESTAURANT_OWNER;

}
