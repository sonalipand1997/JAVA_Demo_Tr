package com.example.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entities.*;
import com.example.repository.*;

@Service
public class OrderService {
	
	@Autowired
	OrderRepository orderrepo;
	
	@Autowired
	CartRepository cartrepo;
	
	public String addOrder(Order order) {
		Order addOrder = orderrepo.save(order);
		return addOrder.getOrder_id()
				+",sucessfully Placed ";
	}
	
public Order getOrderById(int id) {
		
		return orderrepo.findById(id).get();
	}

	
//	public Order updateOrderDetails(Order order,int orderId,int cartId) {
//		
//		Order order1=orderrepo.getOrderById(orderId);
//		Cart cart1=cartrepo.getCartById(cartId);
//
//		//if(rest_owner.getRole().equals(Role.RESTAURANT_OWNER)) {
//		
//		cart1.setProduct(cart1.getProduct().getProduct_id());
//		cart1.getProduct().getProduct_name()
//		    Order orderDetails = orderrepo.save(order);
//		return orderDetails;
//	}
	
	
	public String deleteOrderDetails(int orderId) {
		
		orderrepo.deleteById(orderId);
		return "Order deleted successfully with id : "+orderId;
	}

	public List<Order> getOrder() {
		// TODO Auto-generated method stub
		return orderrepo.findAll();
	}
	
	public List<Order> getNewOrderByUserId(int userId) {
		
		return orderrepo.findNewOrderByUserId(userId);
	}
	
	public List<Order> getPendingOrderByUserId(int userId) {
		
		return orderrepo.findPendingOrderByUserId(userId);
	}

	
	public List<Order> getCompleteOrderByUserId(int userId) {
		
		return orderrepo.findCompleteOrderByUserId(userId);
	}


	public String acceptOrder(int orderId) {
		Order order = orderrepo.findById(orderId).get();
		if(order.getStatus().equals(OrderStatus.REQUESTED)) {
		order.setStatus(OrderStatus.ACCEPTED);
		orderrepo.save(order);
		return "Order Accepted !!!";
		}else if(order.getStatus().equals(OrderStatus.ACCEPTED)) {
			return "Order already accepted!!!";
		}else if(order.getStatus().equals(OrderStatus.INPROGRESS) || order.getStatus().equals(OrderStatus.COMPLETED)) {
			return "Order already Processed !!!";
		}else {
		return "Order already declined !!!";
		}
		
	}

	
	public String rejectOrder(int orderId) {
		
		Order order= orderrepo.findById(orderId).get();
		if(order.getStatus().equals(OrderStatus.REQUESTED)) {
order.setStatus(OrderStatus.DECLINED);
		orderrepo.save(order);
		return "Order Declined ,we will get back to you!!!";
		}else {
			return "order already completed or declined !!!";
		}
	}

	
	public String completeOrder(int orderId) {
		
		Order order = orderrepo.findById(orderId).get();
		
		if(order.getStatus().equals(OrderStatus.INPROGRESS)) {
			if(order.getPayment()!=null) {
		order.setStatus(OrderStatus.COMPLETED);
		orderrepo.save(order);
		return "Order Completed !!!";
		}else {
			return "order is pending!!!";
		}
		}else {
			return "order not InProgress !!!";
		}
	}


	
	

}
