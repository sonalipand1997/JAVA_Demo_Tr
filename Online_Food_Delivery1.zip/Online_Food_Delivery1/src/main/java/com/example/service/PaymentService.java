package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entities.Order;
import com.example.entities.PaymentDetails;
import com.example.repository.OrderRepository;
import com.example.repository.PaymentRepository;

@Service
public class PaymentService {

	@Autowired
	PaymentRepository paymentrepo;
	@Autowired
	OrderRepository orderrepo;
	
	public String makeRequestPayment(int orderId, PaymentDetails payment) {
		Order order = orderrepo.getOrderById(orderId);
		if(order.getPayment()==null) {
			if(order.getUser()!=null) {
				paymentrepo.save(payment);
		order.setPayment(payment);
		orderrepo.save(order);
		return "payment is successfull with transaction Id : "+order.getPayment().getTransactionId();
		}else {
			return "Sorry !! Transaction in Progress";
		}
			}else {
			return "payment already done !!!";
		}
	}

	
}
