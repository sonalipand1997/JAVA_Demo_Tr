package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.entities.Order;


@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {

	@Query("select a from Order a where a.order_id=:id")
	public Order getOrderById(int id);
	
	@Modifying
	@Query(value ="select * from Order where user_id =:userId and status=0",nativeQuery = true)

	public List<Order> findNewOrderByUserId(int userId);
	
	
	@Modifying
	@Query(value ="select * from Order where user_id =:userId and status=1 or status=2",nativeQuery = true)
	List<Order> findPendingOrderByUserId(@Param("userId")int userId);
	
	@Modifying
	@Query("select a from Order a where a.user_id=:userId and a.status=3")
	//@Query(value ="select * from Order where user_id =:userId and status=3 or status=4",nativeQuery = true)
	List<Order> findCompleteOrderByUserId(@Param("userId")int userId);
	


}
