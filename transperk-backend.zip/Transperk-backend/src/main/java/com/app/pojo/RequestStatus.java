package com.app.pojo;

public enum RequestStatus {
	REQUESTED,ACCEPTED,INPROGRESS,COMPLETED,DECLINED
}
