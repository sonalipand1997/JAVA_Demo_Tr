import { BrowserRouter, NavLink,Route, Switch} from 'react-router-dom'
import { ListGroup,ListGroupItem,Button } from 'reactstrap'
import React from 'react'
import AddRestaurant from './AddRestaurant'
import UpdateRestaurannt from './UpdateRestaurant'
import RestaurantList from './RestaurantList'
import AddOwner from './AddOwner'
import UpdateOwner from './UpdateOwner'
import Logout from './Logout'
import OwnerList from './OwnerList';

const AdminDashboard = () => {

  return (

    <div>

      <BrowserRouter>
        {/* <br></br>

        <div className="row">
          <div className="col-md-4 bg-warnimg">
            <h1>jfufv</h1>
          </div>
          <div className="col-md-8">
            <h1>ufucyx</h1>
          </div>

        </div> */}
        <div className="container-fluid">
          <ListGroup horizontal>
            <ListGroupItem>
              <NavLink className="nav-link" exact to="/admin">
                <h5 className="text-center">
                  <i className="fa fa-dashboard"></i>
                  <p>Admin Dashboard</p>
                </h5>
              </NavLink>
            </ListGroupItem>

            
          
            <ListGroupItem>
              <NavLink className="nav-link" exact to="/all">
                <Button outline color="success">
                  Restaurants
                </Button>
              </NavLink>
            </ListGroupItem>


            <ListGroupItem>
              <NavLink className="nav-link" exact to="/allowner">
                <Button outline color="success">
Owner List                </Button>
              </NavLink>
            </ListGroupItem>

          </ListGroup>
        </div>

        <div>
          <Switch>
          <Route path="/all" component={RestaurantList} />
            <Route path="/add" component={AddRestaurant} />
            <Route path="/update" component={UpdateRestaurannt} />
            <Route path="/allowner" component={OwnerList} />
            <Route path="/updateowner" component={UpdateOwner} />
            <Route path="/addowner" component={AddOwner} />




            <Route path="/Logout" component={Logout} />
          </Switch>
        </div>

      </BrowserRouter>
    </div>


  )
}



export default AdminDashboard