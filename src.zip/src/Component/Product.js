import axios from 'axios';
import React, { Component } from 'react'
import { Category } from './Category';


export class Product extends Component {
constructor(props)
{
    super(props);
    this.state=
    {
        product:[],     
        errorMsg:"",
    };
}
    componentDidMount()
    {
        axios
        .get("http://localhost:8080/restowner/getProduct")
        .then((response) => {
            console.log(response.data);
            this.setState({ product:response.data});
         console.log(response.data);
            
        })
        .catch((error) =>{
            console.log("Error is" + error);
            this.setState({errorMsg: "Error receiving data"});
        });
    }

  render() {
      const {product,errorMsg} = this.state;
    return (
      <div class="table">
          <h1>Product List</h1>
          <table>
              <tr>
              <th>Product ID</th>
                  <th>Product Name</th>
                 <th>Product Price</th>
                 <th>Category ID</th>
                 <th>Category Name</th>

                 </tr>
              
          {
              product.length
              ? product.map((product) => <div>
                 <tr>
                      <td>{product.product_id}</td>
                      <td>{product.product_name}</td>
                      <td>{product.product_price}</td>

                      <td>{product.cat.cat_id}</td>
                      <td>{product.cat.cat_name}</td>

                          <td>Add</td>
                     
                  </tr>
               
                      </div>)
              : null
          }
          {errorMsg ? <div>{errorMsg}</div> : null}
          </table>
      </div>
    )
  }
}

export default Product


