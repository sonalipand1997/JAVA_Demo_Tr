import React, { useRef, useState } from "react";

import axios from "axios";

function DeleteRestaurant({rest_id}) 

{
  const [deleteResult, setDeleteResult] = useState(null);
  const fortmatResponse = (res) => {
    return JSON.stringify(res, null, 2);
  };
//    async function deleteAllData() {
//      try {
//        const res = await axios.delete(`/http://localhost:8080/admin/update1/${rest_id}`);
//        const result = {
//          status: res.status + "-" + res.statusText,
//          headers: res.headers,
//          data: res.data,
//        };
//        setDeleteResult(fortmatResponse(result));
//      } catch (err) {
//        setDeleteResult(fortmatResponse(err.response?.data || err));
//      }
//    }

const deleteDataById= ()=>{
    <h2>console.log("id="+rest_id);</h2>

    //event.preventDefault();
    //alert(`The name you entered was: ${id} ${name} ${price}`);
    axios
    .delete("http://localhost:8080/admin/deleteresto/"+rest_id)
    .then((response => console.log(response)))
    .catch(err=>console.log(err))
    alert(`Data deleted successfully`);
    
  
}
  const clearDeleteOutput = () => {
    setDeleteResult(null);
  };
  return (
    <div id="app" className="container">
      <div className="card">
        <div className="card-header">Delete Restaurant</div>
        <div className="card-body">
              <button className="btn btn-sm btn-danger" onClick={deleteDataById}>Delete by Id</button>
            
            <button className="btn btn-sm btn-warning ml-2" onClick={clearDeleteOutput}>Clear</button>
          </div>    
          
          { deleteResult && <div className="alert alert-secondary mt-2" role="alert"><pre>{deleteResult}</pre></div> }      
        </div>
      </div>
    
  );
}
export default DeleteRestaurant;
