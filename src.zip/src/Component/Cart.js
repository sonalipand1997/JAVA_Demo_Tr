import axios from 'axios';
import React, { Component } from 'react'


export class Cart extends Component {
constructor(props)
{
    super(props);
    this.state=
    {
        cart:[],
      user:[],
     
        errorMsg:"",
    };
}
    componentDidMount()
    {
        axios
        .get("http://localhost:8080/user/getCart")
        .then((response) => {
            console.log(response.data);
            this.setState({ cart:response.data});
         console.log(response.data);
            
        })
        .catch((error) =>{
            console.log("Error is" + error);
            this.setState({errorMsg: "Error receiving data"});
        });
    }

  render() {
      const {cart,errorMsg} = this.state;
    return (
      <div class="table">
          <h1>Cart List</h1>
          <table>
              <tr>
                  <th>Cart ID</th>
                  <th>User ID</th>
                  <th>USer Name</th>
                 </tr>
              
          {
              cart.length
              ? cart.map((cart) => <div>
                 <tr>
                      <td>{cart.cart_id}</td>
                     
                     
                  </tr>
               
                      </div>)
              : null
          }
          {errorMsg ? <div>{errorMsg}</div> : null}
          </table>
      </div>
    )
  }
}

export default Cart


