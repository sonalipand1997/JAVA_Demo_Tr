import axios from 'axios';
import React, { Component } from 'react'


export class User extends Component {
constructor(props)
{
    super(props);
    this.state=
    {
        user:[],
      
     
        errorMsg:"",
    };
}
    componentDidMount()
    {
        axios
        .get("http://localhost:8080/user/getUser")
        .then((response) => {
            console.log(response.data);
            this.setState({ user:response.data});
         console.log(response.data);
            
        })
        .catch((error) =>{
            console.log("Error is" + error);
            this.setState({errorMsg: "Error receiving data"});
        });
    }

  render() {
      const {user,errorMsg} = this.state;
    return (
      <div class="table">
          <h1>User List</h1>
          <table>
              <tr>
                  <th>User ID</th>
                  <th>User Name</th>
                 <th>User Email</th>
                 </tr>
              
          {
              user.length
              ? user.map((user) => <div>
                 <tr>
                      <td>{user.user_id}</td>
                      <td>{user.user_name}</td>
                      <td>{user.email}</td>
                     
                     
                  </tr>
               
                      </div>)
              : null
          }
          {errorMsg ? <div>{errorMsg}</div> : null}
          </table>
      </div>
    )
  }
}

export default User


