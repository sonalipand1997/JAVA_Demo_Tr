import React, { useState } from "react";
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';
import { useHistory } from 'react-router-dom';
import Box from '@material-ui/core/Box';
import { Link } from "react-router-dom";

import { Restaurant } from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

export default function AddRestaurant() {
  const classes = useStyles();
  const admin_id = sessionStorage.getItem('admin_id');
let navigate=useHistory();
  const handleSubmit = (event) => {
    event.preventDefault();
    var data = {
      'rest_name': rest_name,
      'address': address,
      'area': area,
      'city': city,
      'pincode': pincode,
      'estimated_deliver_time':estimated_deliver_time,
      'open_time':open_time,
      'close_time':close_time,
      adm:{
        admin_id
      }

    }
    fetch("http://localhost:8080/admin/addrestaurant", {
      method: 'POST',
      headers: {
       'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
                },
      body: JSON.stringify(data),
    })   
    .then(result => {
      console.log(result);
      alert("Added successfully")
        if (alert) {
navigate.push('/all');
        }
  
      return result.json();
    })
    .catch(e => console.log(e));
    
   }

  const [rest_name, setRest_name] = useState('');
  const [address, setAddress] = useState('');
  const [area, setArea] = useState('');
  const [city, setCity] = useState('');
  const [pincode, setPincode] = useState('');
  const [estimated_deliver_time, setEstimated_deliver_time] = useState('');
  const [open_time, setOpen_time] = useState('');
  const [close_time, setClose_time] = useState('');

  return (
    <Container maxWidth="xs">
      <div className={classes.paper}>
      <Typography component="h1" variant="h5">
          Add Restaurant
        </Typography>
        

        <form className={classes.form} onSubmit={handleSubmit}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                autoComplete="fname"
                name="firstName"
                variant="outlined"
                required
                fullWidth
                id="rest_name"
                label="rest_name"
                onChange={(e) => setRest_name(e.target.value)}
                autoFocus
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                variant="outlined"
                required
                fullWidth
                id="address"
                label="address"
                onChange={(e) => setAddress(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                id="area"
                label="area"
                onChange={(e) => setArea(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                id="city"
                label="city"
                onChange={(e) => setCity(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                id="pincode"
                label="pincode"
                onChange={(e) => setPincode(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                id="estimated_deliver_time"
                label="estimated_deliver_time"
                onChange={(e) =>setEstimated_deliver_time(e.target.value)}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                id="open_time"
                label="open_time"
                onChange={(e) => setOpen_time(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                variant="outlined"
                required
                fullWidth
                id="close_time"
                label="close_time"
                onChange={(e) =>setClose_time(e.target.value)}
              />
            </Grid>
         
         
          </Grid>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
          >
            Create
          </Button>
        </form>
      </div>
    </Container>
  );
}
