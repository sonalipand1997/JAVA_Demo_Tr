import axios from 'axios';
import React from 'react'

import { useNavigate } from 'react-router-dom';


export class Restaurant extends React.Component {
constructor(props)
{
    super(props);
    this.state=
    {
        restaurant:[],
     
        errorMsg:"",
    };
}
    componentDidMount()
    {
        axios
        .get("http://localhost:8080/admin/getRest")
        .then((response) => {
            console.log(response.data);
            this.setState({ cart:response.data});
         console.log(response.data);
            
        })
        .catch((error) =>{
            console.log("Error is" + error);
            this.setState({errorMsg: "Error receiving data"});
        });

    }
    navigate=useNavigate();

    deleteID=(rest_id)=>{ axios
        .delete("http://localhost:8080/admin/deleteresto"+rest_id)
        .then((response) => {
            console.log(response.data);
            this.setState({ cart:response.data});
         console.log(response.data);
            
        })
        .catch((error) =>{
            console.log("Error is" + error);
            this.setState({errorMsg: "Error receiving data"});
        });
    }
    update=(rest_id)=>{
        
       console.log(rest_id);
      this.navigate.push('/update/'+rest_id);

    }

  render() {
      const {restaurant,errorMsg} = this.state;
    return (
      <div class="table">
          <h1>Restaurant List</h1>
          <table>
              <tr>
                  <th>restaurant ID</th>
                  <th>restaurant ID</th>
                  <th>restaurant Name</th>
                 </tr>
              
          {
              restaurant.length
              ? restaurant.map((restaurant) => <div>
                 <tr>
                      <td>{restaurant.rest_id}</td>
                      <td><button onClick={()=>this.deleteID(restaurant.rest_id)}>Delete</button></td>
                      <td><button onClick={()=>this.update(restaurant.rest_id)}>Delete</button></td>

                  </tr>
               
                      </div>)
              : null
          }
          {errorMsg ? <div>{errorMsg}</div> : null}
          </table>
      </div>
    )
  }
}

export default Restaurant


