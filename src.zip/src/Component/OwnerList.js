import React, { useEffect, useState } from "react";
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import Container from '@material-ui/core/Container';
import Paper from '@material-ui/core/Paper';
import Box from '@material-ui/core/Box';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
	root: {
	  flexGrow: 1,
	},
	menuButton: {
	  marginRight: theme.spacing(2),
	},
	title: {
	  flexGrow: 1,
	},
	container: {
	  marginTop: theme.spacing(2),
	},
	paper: {
	  padding: theme.spacing(2),
	  color: theme.palette.text.secondary,
	},
  }));
  
export default function OwnerList() {
    const classes = useStyles();
     let navigate=useHistory();
	const [owner, setOwner] = useState([]);
	useEffect(() => {
		OwnerGet()
	}, [])
	
	const OwnerGet = () => {
	  fetch("http://localhost:8080/admin/get")
		.then(res => res.json())
		.then(
		  (result) => {
			setOwner(result)
		  }
		)
	}
  
	 const UpdateOwner =(owner_id) => {
      console.log(owner_id);
	  sessionStorage.setItem('owner_id',owner_id)
		alert("called");
	//    window.location = '/update/'+rest_id
		navigate.push('/updateowner')
	//    window.location = '/update/'+rest_id
	 }
  
	const AccountDelete = owner_id => {
	  var data = {
		'owner_id': owner_id
	  }
	  fetch(`http://localhost:8080/admin/${owner_id}`, {
		method: 'DELETE',
		headers: {
			'Content-Type': 'application/json',
			'Access-Control-Allow-Headers': 'Content-Type',
			'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
					 },
			body: JSON.parse(JSON.stringify(data)),
		})
	  .then(result => {
		console.log(result);
		return result.json();
	})
	.then(result =>{
		console.log(result);
		alert("deleted successfully")
		  if (alert) {
			OwnerGet();
		  }

	 })
	.catch(e => console.log(e));
	
 }







  
  
	return (
	  <div>
		<Container className={classes.container} maxWidth="lg">    
		<Paper className={classes.paper}>
					<Box display="flex">
			  <Box flexGrow={1}>
				<Typography component="h2" variant="h6" color="primary" gutterBottom>
				  Owner
				</Typography>
			  </Box>
			  <Box>
				<Link to="/addowner">
				  <Button variant="contained" color="primary">
					Add Owner
				  </Button>
				</Link>
			  </Box>
			</Box>
			<TableContainer component={Paper}>
			<Table className={classes.table} aria-label="simple table">
			  <TableHead>
				<TableRow>
				  <TableCell align="right">ID</TableCell>
				  <TableCell align="center">Name</TableCell>
				  <TableCell align="left">Email</TableCell>
				 </TableRow>
			  </TableHead>
			  <TableBody>
				{owner.map((owner) => (
				  <TableRow key={owner.ID}>
					<TableCell align="right">{owner.owner_id}</TableCell>
					<TableCell align="center">
					  <Box display="flex" justifyContent="center">
						<TableCell align="center">{owner.owner_name}</TableCell>
					  </Box>
					</TableCell>
					<TableCell align="left">{owner.email}</TableCell>
					<TableCell align="center">
					  <ButtonGroup color="primary" aria-label="outlined primary button group">
						{<Button onClick={() => UpdateOwner(owner.owner_id)}>Edit</Button>}
						<Button onClick={() => AccountDelete(owner.owner_id)}>Del</Button>
					  </ButtonGroup>
					</TableCell>
				  </TableRow>
				))}
			  </TableBody>
			</Table>
		  </TableContainer>
		  </Paper>
		</Container>
	  </div>
	  
	);
  }
  