import axios from 'axios';

const OWNER_API_BASE_URL = "http://localhost:8080/admin";


class Rest_Owner {

       saveOwnerDetails(restowner){
        return axios.post(OWNER_API_BASE_URL, restowner);
    }

    
    getOwnerById(ownerId){
        return axios.get(OWNER_API_BASE_URL + '/' + ownerId);
    }

    updateownerDetails(ownerId, detachedOwner){
        return axios.put(OWNER_API_BASE_URL + '/'+ 'update' +'/'+ ownerId, detachedOwner);
    }

    deleteownerDetails(ownerId){
        return axios.delete(OWNER_API_BASE_URL + '/' + ownerId);
    }



}

export default new Rest_Owner()