import React, { useEffect, useState } from "react";
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import Container from '@material-ui/core/Container';
import Paper from '@material-ui/core/Paper';
import Box from '@material-ui/core/Box';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
	root: {
	  flexGrow: 1,
	},
	menuButton: {
	  marginRight: theme.spacing(2),
	},
	title: {
	  flexGrow: 1,
	},
	container: {
	  marginTop: theme.spacing(2),
	},
	paper: {
	  padding: theme.spacing(2),
	  color: theme.palette.text.secondary,
	},
  }));
  
export default function RestaurantList() {
    const classes = useStyles();
     let navigate=useNavigate();
	const [restaurant, setRestaurant] = useState([]);
	useEffect(() => {
		RestaurantGet()
	}, [])
	
	const RestaurantGet = () => {
	  fetch("http://localhost:8080/admin/getRest")
		.then(res => res.json())
		.then(
		  (result) => {
			setRestaurant(result)
		  }
		)
	}
  
	 const UpdateRestaurant =(rest_id) => {
      console.log(rest_id);
	  sessionStorage.setItem('rest_id',rest_id)
		alert("called");
	//    window.location = '/update/'+rest_id
		navigate('/update')
	//    window.location = '/update/'+rest_id
	 }
  
	const RestaurantDelete = rest_id => {
	  var data = {
		'rest_id': rest_id
	  }
	  fetch(`http://localhost:8080/admin/deleteresto/${rest_id}`, {
		method: 'DELETE',
		headers: {
			'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*',
			'Access-Control-Allow-Headers': 'Content-Type',
			'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
					 },
			body: JSON.parse(JSON.stringify(data)),
		})
	  .then(result => {
		console.log(result);
		return result.json();
	})
	.then(result =>{
		console.log(result);
		alert("deleted successfully")
		  if (alert) {
			RestaurantGet();
		  }

	 })
	.catch(e => console.log(e));
	
 }







  
  
	return (
	  <div>
		<Container className={classes.container} maxWidth="lg">    
		<Paper className={classes.paper}>
					<Box display="flex">
			  <Box flexGrow={1}>
				<Typography component="h2" variant="h6" color="primary" gutterBottom>
				  Restaurant
				</Typography>
			  </Box>
			  <Box>
				<Link to="/add">
				  <Button variant="contained" color="primary">
					CREATE
				  </Button>
				</Link>
			  </Box>
			</Box>
			<TableContainer component={Paper}>
			<Table className={classes.table} aria-label="simple table">
			  <TableHead>
				<TableRow>
				  <TableCell align="right">ID</TableCell>
				  <TableCell align="center">Name</TableCell>
				  <TableCell align="left">Address</TableCell>
				  <TableCell align="left">Area</TableCell>
				  <TableCell align="left">City</TableCell>
				  <TableCell align="center">Pincode</TableCell>
				</TableRow>
			  </TableHead>
			  <TableBody>
				{restaurant.map((restaurant) => (
				  <TableRow key={restaurant.ID}>
					<TableCell align="right">{restaurant.rest_id}</TableCell>
					<TableCell align="center">
					  <Box display="flex" justifyContent="center">
						<TableCell align="center">{restaurant.rest_name}</TableCell>
					  </Box>
					</TableCell>
					<TableCell align="left">{restaurant.address}</TableCell>
					<TableCell align="left">{restaurant.area}</TableCell>
					<TableCell align="left">{restaurant.city}</TableCell>
					<TableCell align="center">
					  <ButtonGroup color="primary" aria-label="outlined primary button group">
						{<Button onClick={() => UpdateRestaurant(restaurant.rest_id)}>Edit</Button>}
						<Button onClick={() => RestaurantDelete(restaurant.rest_id)}>Del</Button>
					  </ButtonGroup>
					</TableCell>
				  </TableRow>
				))}
			  </TableBody>
			</Table>
		  </TableContainer>
		  </Paper>
		</Container>
	  </div>
	  
	);
  }
  