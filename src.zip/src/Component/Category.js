import axios from 'axios';
import React, { Component } from 'react'


export class Category extends Component {
constructor(props)
{
    super(props);
    this.state=
    {
        category:[],
      
     
        errorMsg:"",
    };
}
    componentDidMount()
    {
        axios
        .get("http://localhost:8080/restowner/getCategory")
        .then((response) => {
            console.log(response.data);
            this.setState({ category:response.data.data});
         console.log(response.data);
            
        })
        .catch((error) =>{
            console.log("Error is" + error);
            this.setState({errorMsg: "Error receiving data"});
        });
    }

  render() {
      const {category,errorMsg} = this.state;
    return (
      <div class="table">
          <h1>Category List</h1>
          <table>
              <tr>
                  <th>Category ID</th>
                  <th>Category Name</th>
                 </tr>
              
          {
    category.length
                            ?
     category.map((category) => <div>
                 <tr>
                      <td>{category.cat_id}</td>
                      <td>{category.cat_name}</td>
                      <td>{category.products.product_id}</td>
                                         
                     
                  </tr>
               
                      </div>)
                            : null

          }
          
          {errorMsg ? <div>{errorMsg}</div> : null}
          </table>
      </div>
    )
  }
}

export default Category


