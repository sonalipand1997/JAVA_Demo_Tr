import { useState } from 'react';
//import { url } from '../common/constant';
import { Link, useHistory } from 'react-router-dom'
import axios from 'axios';
import '../index.css';
import { validEmail, validPassword, validPhoneNo } from '../common/Regex';
const Signup = () => {

  const history = useHistory();
  const [InvalidErr, setInvalidErr] = useState(false)
  const [InvalidErrMsg, setInvalidErrMsg] = useState("")

  const [name, setName] = useState('')
  const [role, setRole] = useState('')

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [phone_no, setPhone_no] = useState('')
  

  const [nameErr, setNameErr] = useState(false)
  const [nameErrMsg, setNameErrMsg] = useState("")
  const [emailErr, setEmailErr] = useState(false)
  const [emailErrMsg, setEmailErrMsg] = useState("")
  const [phone_noErr, setPhone_noErr] = useState(false)
  const [phone_noErrMsg, setPhone_noErrMsg] = useState("")
  const [pwdErr, setPwdErr] = useState(false)
  const [pwdErrMsg, setPwdErrMsg] = useState("")
  
  const backToHome = () => {
    history('/');
  }
  const signup = (() => {

    setNameErr(false)


    setEmailErr(false)
    setPhone_noErr(false)
    setPwdErr(false)


    if (role === "" || role.length === 0) {
      alert("Please enter Role")
    }
    else if (name.length === 0) {
      setNameErr(true)
      setNameErrMsg("please enter name")
      alert("please enter first name")
    }

    else if (email.length === 0) {
      setEmailErr(true)
      setEmailErrMsg("please enter email")
      alert("please enter email")
      //alert(emailErrMsg)
    } else if (!validEmail.test(email)) {
      setEmailErr(true)
      setEmailErrMsg("please enter valid email")
      alert("please enter valid email")
      //alert(emailErrMsg)
    }

    else if (password.length === 0) {
      setPwdErr(true)
      setPwdErrMsg("please enter password")
      alert("please enter password")
    }
    //  else if (!validPassword.test(password)){
    //    setPwdErr(true)
    //    setPwdErrMsg("please enter valid password")
    //    alert("please enter valid password")
    //  }

    else if (phone_no.length === 0) {
      setPhone_noErr(true)
      setPhone_noErrMsg("please enter phone number")
      alert("please enter phone number")

    } else if (!validPhoneNo.test(phone_no)) {
      setPhone_noErr(true)
      setPhone_noErrMsg("please enter valid phone number")
      alert("please enter valid phone number")
    }


    else {


      const body = { name: name, role: role, email: email, password: password, phone_no: phone_no}


      if (role === "ADMIN") {
        console.log('role ' + role);
        axios.post(`http://localhost:8080/admin/addadmin`, body).then(response => {
          const result = response.data;
          if (result) {
            alert('succcess')
            history.push('/Signin')
          }
          else {
            alert('error')
          }
        }).catch(err => {
          setInvalidErr(true)
          setInvalidErrMsg("enter input is not valid input")
        })
      } 

    }


  })
  return (

    <div className="container">
      <br></br>
      <div >
        <div className="mb-3" className="sign">
          <h1>SignUp</h1>
          <br></br><div className="mb-3">
            <label><h5>Join Us As</h5></label>
            <select className="form-select"
              onChange={(e) => {
                setRole(e.target.value)
              }}>
              <option>select</option>
              <option value="ADMIN">admin</option>
              <option value="USER">user</option>
            </select>
          </div>
          <h5>Name: </h5  >
          <input
            onChange={(e) => {
              setName(e.target.value)
            }}
            className="form-control" type="text" placeholder="Enter Name" />
          <br></br>

          <h5>Email: </h5>
          <input
            onChange={(e) => {
              setEmail(e.target.value)
            }}
            className="form-control" type="email" placeholder="Enter Email" />
          <br></br>
          <h5>password: </h5>
          <input
            onChange={(e) => {
              setPassword(e.target.value)
            }}
            className="form-control" type="password" placeholder="Enter Password" />
          <br></br>
          <h5>Phone Number: </h5>
          <input
            onChange={(e) => {
              setPhone_no(e.target.value)
            }}
            className="form-control" type="text" placeholder="Enter Phone Number" />

          {/* AdharNo: <input
            onChange={(e) => {
              setAdharNo(e.target.value)
            }}
            className="form-control" type="text" /> */}
          <br></br>
          <h5>Email:</h5>
          <input
            onChange={(e) => {
              setEmail(e.target.value)
            }}
            className="form-control" type="email" placeholder="Enter Address" />

          <br></br>
          <br />
          <br></br>
          <button onClick={signup} className="btn btn-success"><i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp;Sign Up</button> &nbsp;
          <button onClick={backToHome}className="btn btn-outline-info"> 
              <i class="fa fa-home fa-lg" aria-hidden="true"></i>&nbsp; Home</button>
          {/* <button onClick={Log}className="btn btn-success">Home</button> */}
          {/* <button onClick={handleSubmit} className="btn btn-success">RESET</button> */}
          {/* <button onClick={resetInputField} className="btn btn-success">RESET</button> */}


        </div>
      </div>
    </div>
  )
}


export default Signup