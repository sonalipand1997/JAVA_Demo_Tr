import React from 'react'

function OurTeam() {
  return (
    <div>OurTeam</div>
  )
}

export default OurTeam