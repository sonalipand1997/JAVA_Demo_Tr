import { BrowserRouter,Switch,Route } from 'react-router-dom';
import OwnerList from './Component/OwnerList';
import AdminDashboard from './Component/AdminDashboard';
import { createBrowserHistory } from 'history'
import Signin from './Component/SignIn';
import Signup from './Component/SignUp';
import Home from './Component/Home';

  const history = createBrowserHistory();

  function App() {
  
    return (
  
      <div>
        
        <BrowserRouter history={history}>
        
          {/* <nav className="navbar navbar-expand-lg navbar-light heading">
            <div className="container-fluid">
            {/* < NavLink className="navbar-brand" to="/">style={{ height: "50px" }} alt="logo" />
                  </NavLink>
                      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                          <span className="navbar-toggler-icon"></span>
                      </button> 
            */}
          {/* <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse" id="navbarNav">
                <ul className="navbar-nav">
  
                  <li>
                    <Link className="nav-link" to="/signin">
                     <b> Signin</b>
                    </Link>
                  </li>
                  <li>
                    <Link className="nav-link" to="/signup">
                      <b>Signup</b>
                    </Link>
                    </li>
                </ul>
              </div>
            </div>
          </nav>*/}
          <div>
            <Switch>
              <Route path="/" exact component={Home}></Route>
            </Switch>
          </div>
  
          <div className="">
            <Switch>
           
              <Route path="/signin" component={Signin} />
              <Route path="/signup" component={Signup} />
              <Route path="/owner" component={OwnerList} />
              <Route path="/admin" component={AdminDashboard} />
            </Switch>
  
          </div>
        </BrowserRouter>
</div>
  );
}

export default App;
