import logo from './logo.svg';
import UpdateRestaurant from './Component/UpdateRestaurant';
import UserList from './Component/RestaurantList';
import { BrowserRouter,Routes,Route,Link } from 'react-router-dom';
import AddRestaurant from './Component/AddRestaurant';
function App() {

  return (
    <div className="App">

<BrowserRouter>
<Routes>
       <Route path="/" element={<UserList/>}/>
       <Route path="/add" element={<AddRestaurant/>}/>
       <Route exact path='/update' element={<UpdateRestaurant/>}/>


</Routes>


<Link to="/add">Add</Link><br/> 
<Link to="/all">All</Link><br/>
<Link to="/update">Update</Link>


   </BrowserRouter> </div>
  );
}

export default App;
